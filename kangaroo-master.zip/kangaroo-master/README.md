# kangaroo
A dataset of 183 images and annotations for kangaroo detection.
